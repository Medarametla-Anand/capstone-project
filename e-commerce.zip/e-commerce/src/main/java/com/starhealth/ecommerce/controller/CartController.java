package com.starhealth.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.starhealth.ecommerce.entity.Cart;
import com.starhealth.ecommerce.service.CartService;

/*
 * @Author : Anand
 * Date    : 19-10-2022
 * Description : Cart Controller used to add and retrieve products from database
 * 
 */

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class CartController {

	@Autowired
	CartService cartService;
	
	@PostMapping("/addProductsToCart")
	public Cart addproductsToCart(@RequestBody Cart cart) {
		return cartService.addProductToCart(cart);
	}

	@GetMapping("/getProductsFromCart")
	public List<Cart> getProductsFromCart() {
		return cartService.getAllProductsFromCart();
	}
}
