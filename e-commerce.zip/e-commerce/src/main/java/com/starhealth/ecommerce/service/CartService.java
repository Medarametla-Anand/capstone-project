package com.starhealth.ecommerce.service;

import java.util.List;

import com.starhealth.ecommerce.entity.Cart;

public interface CartService {
	
	public Cart addProductToCart(Cart cart);
	
	public List<Cart>  getAllProductsFromCart();
	
	public void deleteProductFromCart(int productId);

}
