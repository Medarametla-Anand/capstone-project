package com.starhealth.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.starhealth.ecommerce.entity.Cart;
import com.starhealth.ecommerce.entity.Product;
import com.starhealth.ecommerce.service.CartService;
import com.starhealth.ecommerce.service.ProductService;

/*
 * @Author : Anand
 * Date    : 19-10-2022
 * Description : Product Controller used to perform crud opertaions 
 * 
 */
@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class ProductController {

	@Autowired
	ProductService productService;

	@PostMapping("/addProduct")
	public Product addProduct(@RequestBody Product product) {
		return productService.addProduct(product);
	}

	@PutMapping("/updateProduct")
	public Product updateProduct(@RequestBody Product product) {
		return productService.updateProduct(product);
	}

	@GetMapping("/getProduct/{id}")
	public Product addProduct(@PathVariable int id) {
		return productService.getProductById(id);
	}

	@GetMapping("/getAllProducts")
	public List<Product> getAllProducts() {
		return productService.getAllProducts();
	}

	@DeleteMapping("/deleteProduct/{productId}")
	public void deleteProductById(@PathVariable int productId) {
		productService.deleteProductById(productId);
	}

}
