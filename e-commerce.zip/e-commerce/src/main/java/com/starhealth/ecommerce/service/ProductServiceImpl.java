package com.starhealth.ecommerce.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhealth.ecommerce.entity.Product;
import com.starhealth.ecommerce.repository.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepo productRepo;
	
	/*
	 * Author : Anand
	 * Date :19-10-2022
	 * Description : product add service
	 * Params :Product object
	 * return : Product entity object
	 * Exception :throws ProductNotFoundException
	 * 
	 */
	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepo.save(product);
	}
	
	/*
	 * Author : Anand
	 * Date :19-10-2022
	 * Description : product update service
	 * Params :Product object
	 * return : Product entity object
	 * Exception :throws ProductNotFoundException
	 * 
	 */

	@Override
	public Product updateProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepo.save(product);
	}

	
	/*
	 * Author : Anand
	 * Date :19-10-2022
	 * Description : getProductById service
	 * Params :Product object
	 * return : Product entity object
	 * Exception :throws ProductNotFoundException
	 * 
	 */
	@Override
	public Product getProductById(int productId) {
		// TODO Auto-generated method stub
		return productRepo.findById(productId).orElse(new Product());
	}

	
	/*
	 * Author : Anand
	 * Date :19-10-2022
	 * Description : getAllProducts service
	 * Params :Product object
	 * return : Product entity object
	 * Exception :throws ProductNotFoundException
	 * 
	 */
	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productRepo.findAll();
	}
	
	/*
	 * Author : Anand
	 * Date :19-10-2022
	 * Description : deleteProductById service
	 * Params :Product object
	 * return : Product entity object
	 * Exception :throws ProductNotFoundException
	 * 
	 */

	@Override
	public void deleteProductById(int id) {
		// TODO Auto-generated method stub
		productRepo.deleteById(id);;
	}

}
