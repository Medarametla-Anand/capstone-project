package com.starhealth.ecommerce.service;

import com.starhealth.ecommerce.entity.User;

public interface UserService {
	
  public User addUser(User user);
  
  public User getUserByUserName(String userName,String role);

}
