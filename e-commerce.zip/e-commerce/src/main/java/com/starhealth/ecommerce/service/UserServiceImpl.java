package com.starhealth.ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhealth.ecommerce.entity.User;
import com.starhealth.ecommerce.repository.UserRepo;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserRepo userRepo;

	
	/*
	 * Author : Anand
	 * Date :19-10-2022
	 * Description : add user service
	 * Params :User object
	 * return : User entity object
	 * Exception :throws ProductNotFoundException
	 * 
	 */
	@Override
	public User addUser(User user) {

		return userRepo.save(user);
	}
	
	/*
	 * Author : Anand
	 * Date :19-10-2022
	 * Description : getUserByUserName service
	 * Params :User object
	 * return : User entity object
	 * Exception :throws ProductNotFoundException
	 * 
	 */

	@Override
	public User getUserByUserName(String userName, String role) {
		// TODO Auto-generated method stub
		return userRepo.findByUsername(userName, role);
	}

}
