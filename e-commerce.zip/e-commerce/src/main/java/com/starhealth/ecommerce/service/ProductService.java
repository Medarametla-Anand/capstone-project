package com.starhealth.ecommerce.service;

import java.util.List;

import com.starhealth.ecommerce.entity.Product;

public interface ProductService {

	public Product addProduct(Product product);

	public Product updateProduct(Product product);

	public Product getProductById(int productId);

	public List<Product> getAllProducts();
	
	public void deleteProductById(int id);
	
	

}
