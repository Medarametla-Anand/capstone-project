package com.starhealth.ecommerce.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.starhealth.ecommerce.entity.User;

public interface UserRepo extends JpaRepository<User, Integer>{
	
	@Query("select user  from User user where user_name=?1 and role=?2")
	public User findByUsername(String userName,String role);

}
