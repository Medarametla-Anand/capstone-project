package com.starhealth.ecommerce.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhealth.ecommerce.entity.Cart;
import com.starhealth.ecommerce.repository.CartRepo;

@Service
public class CartServiceImpl implements CartService {
	
	@Autowired
	CartRepo cartRepo;

	
	/*
	 * Author : Anand
	 * Date :19-10-2022
	 * Description : addProductToCart service
	 * Params :Cart object
	 * return : Cart entity object
	 * Exception :throws ProductNotFoundException
	 * 
	 */
	@Override
	public Cart addProductToCart(Cart cart) {
		// TODO Auto-generated method stub
		return cartRepo.save(cart);
	}
	
	/*
	 * Author : Anand
	 * Date :19-10-2022
	 * Description : getAllProductsFromCart service
	 * Params :Cart object
	 * return : Cart entity object
	 * Exception :throws ProductNotFoundException
	 * 
	 */

	@Override
	public List<Cart> getAllProductsFromCart() {
		// TODO Auto-generated method stub
		return cartRepo.findAll();
	}
	
	/*
	 * Author : Anand
	 * Date :19-10-2022
	 * Description : deleteProductFromCart service
	 * Params :Cart object
	 * return : Cart entity object
	 * Exception :throws ProductNotFoundException
	 * 
	 */

	@Override
	public void deleteProductFromCart(int productId) {
		// TODO Auto-generated method stub
		 cartRepo.deleteById(productId);
	}
	
	
	

}
