package com.starhealth.ecommerce.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.starhealth.ecommerce.entity.Product;

public interface  ProductRepo extends JpaRepository<Product, Integer> {

}
