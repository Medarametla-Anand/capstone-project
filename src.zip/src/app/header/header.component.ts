import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  userName: any = '';

  flag: boolean = false;

  constructor(private router: Router, private service: LoginService) {}

  ngOnInit(): void {
    this.userName = localStorage.getItem('userName');
    console.log(this.userName);
  }

  logOut() {
    localStorage.removeItem('userName');

    this.router.navigateByUrl('/signIn');
    this.flag = true;
  }
}
