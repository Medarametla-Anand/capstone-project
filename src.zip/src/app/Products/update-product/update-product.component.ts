import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from 'src/app/Product';
import { ProductService } from 'src/app/product.service';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent implements OnInit {

  id:number = 0;

  constructor(private router:Router, private productService:ProductService ,private route:ActivatedRoute) {


    route.params.subscribe( (param:any) => {this.id = param['productId']; console.log(this.id)});
   }

  ngOnInit(): void {
  }



  updateProduct(data:Product){

      console.log('updating data '+data)

      this.productService.updateProduct(data);

      alert("Employee Updated Successfully!")
      this.router.navigateByUrl('/dashboard');

  }

}
