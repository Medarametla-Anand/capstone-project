import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from 'src/app/Product';
import { ProductService } from 'src/app/product.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

   constructor( private router:Router,private productService: ProductService) {}

  product: Product = new Product();
  productList: Product[] = [];

  

  ngOnInit(): void {
    this.getAllProducts();
  }

  getAllProducts() {
    this.productService.getAllProducts().subscribe((products: Product[]) => {
      this.productList = products;
      console.log(this.productList);
    });

// addToCart(data:Product){
//   this.productService.addProduct

// }
  }

}
