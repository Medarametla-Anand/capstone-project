import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from '../Product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  constructor( private router:Router,private productService: ProductService) {}

  product: Product = new Product();
  productList: Product[] = [];

  ngOnInit(): void {}

  getAllProducts() {
    this.productService.getAllProducts().subscribe((products: Product[]) => {
      this.productList = products;
      console.log(this.productList);
    });

  }

   deleteProductById(id:number){


  this.productService.deleteProductById(id).subscribe( (status:string) => {console.log(status)});
        alert('deleting record with id '+id)

      this.router.navigateByUrl('/dashboard');

    }

}
