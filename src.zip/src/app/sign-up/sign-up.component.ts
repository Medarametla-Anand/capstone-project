import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';
import { User } from '../User';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css'],
})
export class SignUpComponent implements OnInit {
  constructor(private router: Router, private signUpservice: LoginService) {}

  ngOnInit(): void {}
  signUp(data: User) {
    data.role = 'user';
    this.signUpservice.signUp(data);
    this.router.navigateByUrl('/login');
  }
}
