import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';
import { User } from '../User';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css'],
})
export class SignInComponent implements OnInit {
  constructor(private router: Router, private loginService: LoginService) {}

  ngOnInit(): void {}
  user: User = new User();
  userList: User[] = [];

  signIn(f: NgForm) {
    const { userName, role } = f.form.value;

    this.loginService.signIn(userName, role).subscribe((users: User) => {
      this.user = users;
      if (this.user.role == 'admin') {
        this.router.navigateByUrl('/dashboard');
      } else if (this.user.role == 'user') {
        this.router.navigateByUrl('/products');
      } else {
        alert('please check email and password');
      }

      localStorage.setItem('userName', userName);
      console.log(this.user);
    });
  }
}
