export class User{
    userName:String=""
	  password:String="";
	  role:String="";
	  email:String=""
	  mobileNumber:number=0;
	  address:String="";
}