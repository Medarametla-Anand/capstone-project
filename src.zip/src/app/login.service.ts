import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { Observable} from 'rxjs';
import { User } from './User';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http:HttpClient) { }

  url:string="http://localhost:8080/api/v1";

  signIn(userName:string,role:string):Observable<User>{

    return this.http.get<User>(this.url+'/getUser/'+userName+'/'+role)

  }

  signUp(user:User){
    return this.http.post<User>(this.url+'/addUser',user).subscribe((data:User)=>{
console.log(data)
    })
  }

  getUser(){
    
  }
}
