import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CartComponent } from './cart/cart.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AddProductComponent } from './Products/add-product/add-product.component';
import { ProductComponent } from './Products/product/product.component';
import { UpdateProductComponent } from './Products/update-product/update-product.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { SignUpComponent } from './sign-up/sign-up.component';

const routes: Routes = [
  { path: '', component: SignInComponent },
  { path: 'products', component: ProductComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'addProduct', component: AddProductComponent },
  { path: 'updateProduct', component: UpdateProductComponent },
  { path: 'signUp', component: SignUpComponent },
  { path: 'cart', component: CartComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
