export class Product{
    productId:number=0;
    productName:string="";
    productType:string="";
    productPrice:number=0;
    productImage:string="";
    productQuantity:number=0;
}
